import progressbarIcon from "./progressbarIcon.svg";
import copy from "./copy.svg";
import logo from "./logo.svg";
import invezz from "./invezz.png";
import crypto from "./crypto.png";
import blockonomy from "./blockonomi.png";
import tradingview from "./tradingview.png";
import bloomberg from "./bloomberg.png";
import zycrypto from "./zycrypto.png";

export {
  progressbarIcon,
  copy,
  logo,
  invezz,
  crypto,
  blockonomy,
  tradingview,
  bloomberg,
  zycrypto,
};
